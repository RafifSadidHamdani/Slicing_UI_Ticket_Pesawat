# Slicing UI Ecommence

Latihan Slicing UI Ecommence

## Sreenshot
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_ui_ecommence/main/screenshot/dashboard.png" alt="" width="300">
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_ui_ecommence/main/screenshot/product_detail.png" alt="" width="300">
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_ui_ecommence/main/screenshot/cart.png" alt="" width="300">

## Referensi Desain
[Ecommerce Mobile App UI Kit](https://www.figma.com/file/1su6p5iKu7mDsnprf04R4J/Ecommerce-Mobile-App-UI-kit-(Community)?type=design&node-id=0-1&t=ZibMdPs2XRuvWf76-0)
