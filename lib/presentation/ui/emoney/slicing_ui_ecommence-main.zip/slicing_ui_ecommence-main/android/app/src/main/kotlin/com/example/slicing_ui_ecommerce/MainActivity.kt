package com.example.slicing_ui_ecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
